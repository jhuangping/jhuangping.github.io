const helpers = {
  getQuery: ()=> {
    console.log('getQuery');
    return 'getQuery';
  }
}
