console.log(`return ${helpers.getQuery()}`);
console.log(`return ${helpers.getQuery()} line 2`);
// ES6 範例程式碼
