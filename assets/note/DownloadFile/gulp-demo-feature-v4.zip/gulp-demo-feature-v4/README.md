# 六角學院 Gulp 範例

## 安裝環境

本範例是使用 `gulp 3.9.1`，另有使用 Bower 載入前端套件。

```
npm install gulp -g
npm install bower -g
```

## 執行

請依序執行以下指令來執行 gulp。

```
npm install
bower install
gulp
```

[範例網站](https://hexschool.github.io/gulp-demo/)。
